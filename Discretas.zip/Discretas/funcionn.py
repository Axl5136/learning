from flask import Flask, render_template, request
import os

app = Flask(__name__)

# Lógica existente

def prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n**0.5)+1):
        if n % i == 0:
            return False
    return True

def compositive(n):
    return n > 1 and not prime(n)

def even(n):
    return n % 2 == 0

def odd(n):
    return not even(n)

def sum_of_divisors(n):
    return sum(i for i in range(1, n) if n % i == 0)

def perfect(n):
    return n > 0 and sum_of_divisors(n) == n

def deficient(n):
    return n > 0 and sum_of_divisors(n) < n

def classify(n):
    classification = {
        "Prime": prime(n),
        "Composite": compositive(n),
        "Even": even(n),
        "Odd": odd(n),
        "Perfect": perfect(n),
        "Deficient": deficient(n)
    }
    return classification

def parse_and_classify_file(file_path):
    try:
        with open(file_path, 'r') as file:
            numbers = file.readlines()

        if not numbers:
            return "El archivo está vacío."

        results = []
        for line in numbers:
            line = line.strip()
            if line.isdigit():
                num = int(line)
                classification = classify(num)
                results.append((num, classification))
            else:
                results.append((line, "Línea inválida"))
        return results
    except FileNotFoundError:
        return f"File not found: {file_path}"
    except Exception as e:
        return f"An error occurred: {e}"

# Rutas de Flask
@app.route('/')
def upload_file():
    return render_template('upload.html')

@app.route('/uploader', methods=['POST'])
def uploader_file():
    if 'file' not in request.files:
        return 'No file part'
    file = request.files['file']
    if file.filename == '':
        return 'No selected file'
    if file:
        file_path = os.path.join('uploads', file.filename)
        os.makedirs('uploads', exist_ok=True)
        file.save(file_path)
        results = parse_and_classify_file(file_path)
        return render_template('results.html', results=results)

if __name__ == '__main__':
    app.run(debug=True)
