import time
from time import sleep
import sys

def print_lyrics():
    first = ["i cannot vanish"]
    second = ["you will not scare me"]
    third = ["try to get through it"]
    fourth = ["try to push through it"]
    fifth = ["you were not thinking that i will not do it"]
    sixth = ["they be lovin' someone"]
    seventh = ["and i'm another story"]
    eigth = ["take the next ticket"]
    ninth = ["take the next train"]
    tenth = ["why would i do it?"]
    eleventh = ["anyone'd think that"] # then baby

    twelfth = ["baby"]
    thirteenth = ["now i'm ready"]
    fourteenth = ["moving on"]
    fifteenth = ["oh, but maybe"]
    sixteenth = ["i was ready"]
    seventeenth = ["all along"]
    eighteenth = ["oh, i'm ready"]
    nineteenth = ["for the moment"]
    twentieth = ["and the sound"]
    twentyfirst = ["oh, but maybe"]
    twentysecond = ["i was ready"]
    twentythird = ["all along"]
    twentyfourth = ["oh, baby"]
    twentyfifth = ["now i'm ready"]

    twentysixth = ["moving on"]
    twentyseventh = ["oh, but maybe"]
    twentyeighth = ["i was ready"]
    twentyninth = ["all along"]
    

    
    delay1 = 0.3
    delay2 = 0.1
    delay3 = 0.3
    delay4 = 0.3
    delay5 = 0.6
    delay6 = 0.3
    delay7 = 0.4
    delay8 = 0.6
    delay9 = 0.5
    delay10 = 0.5

    delay11 = 0.3
    delay12 = 0.8
    delay13 = 1
    delay14 = 1
    delay15 = 1
    delay16 = 1
    delay17 = 1
    delay18 = 1
    delay19 = 0.9
    delay20 = 0.9
    delay21 = 0.9
    delay22 = 0.9
    delay23 = 0.9
    delay24 = 0.9
    delay25 = 0.9
    delay26 = 0.9
    delay27 = 0.9
    delay28 = 0.9
    delay29 = 0.9
    

    for line in first:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.08)
        time.sleep(delay1)
        print('')

    for line in second:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.06)
        time.sleep(delay2)
        print('')

    for line in third:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.08)
        time.sleep(delay3)
        print('')
    
    for line in fourth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.06)
        time.sleep(delay4)
        print('')
    
    for line in fifth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.07)
        time.sleep(delay5)
        print('')
    
    for line in sixth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.06)
        time.sleep(delay6)
        print('')

    for line in seventh:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.07)
        time.sleep(delay7)
        print('')

    for line in eigth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.05)
        time.sleep(delay8)
        print('')

    for line in ninth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.05)
        time.sleep(delay8)
        print('')

    for line in tenth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.08)
        time.sleep(delay10)
        print('')

    for line in eleventh:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.06)
        time.sleep(delay11)
        print('')

    for line in twelfth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.1)
        time.sleep(delay12)
        print('')
    
    for line in thirteenth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.06)
        time.sleep(delay13)
        print('')
    
    for line in fourteenth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.08)
        time.sleep(delay14)
        print('')
    
    for line in fifteenth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.08)
        time.sleep(delay15)
        print('')

    for line in sixteenth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.07)
        time.sleep(delay16)
        print('')

    for line in seventeenth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.05)
        time.sleep(delay17)
        print('')

    for line in eighteenth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.07)
        time.sleep(delay18)
        print('')
    
    for line in nineteenth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.08)
        time.sleep(delay19)
        print('')

    for line in twentieth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.08)
        time.sleep(delay20)
        print('')

    for line in twentyfirst:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.08)
        time.sleep(delay21)
        print('')
    
    for line in twentysecond:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.06)
        time.sleep(delay22)
        print('')

    for line in twentythird:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.06)
        time.sleep(delay23)
        print('')
    
    for line in twentyfourth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.07)
        time.sleep(delay24)
        print('')
    
    for line in twentyfifth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.06)
        time.sleep(delay25)
        print('')

    for line in twentysixth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.07)
        time.sleep(delay26)
        print('')

    for line in twentyseventh:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.07)
        time.sleep(delay27)
        print('')

    for line in twentyeighth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.05)
        time.sleep(delay28)
        print('')

    for line in twentyninth:
        for c in line:
            print(c, end='')
            sys.stdout.flush()
            sleep(0.05)
        time.sleep(delay29)
        print('')

print_lyrics()
